package com.example.hotel;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class Hotel_Review extends AppCompatActivity {

    Button btnNew;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hotel_review);

        btnNew=(Button)findViewById(R.id.btnNew);
        final EditText editTextTitle = (EditText) findViewById(R.id.editTextTitle);
        btnNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String strID = editTextTitle.getText().toString();

            }
        });
    }
}
