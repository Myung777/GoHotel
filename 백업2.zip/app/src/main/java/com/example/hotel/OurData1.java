package com.example.hotel;

public class OurData1 {
    public static  String[] title = new String[]{
            "김누리",
            "강우연",
            "이태희",
            "박현수",


    };
    public static  String[] content = new String[]{
            "너무너무 좋아요\n" +
                    "깔끔한 시설에 한번더 놀라게 되네요!!\n또 방문하고 싶네요~ \n사장님 행복하세요. ",
            "한국말",
            "하와이",
            "와르르",


    };
    public  static  int[] picturePath = new int[]{
            R.drawable.hotel1,
            R.drawable.hotel1,
            R.drawable.hotel2,
            R.drawable.hotel2,

    };
}
