package com.example.hotel;

import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;

import static com.example.hotel.Hotel_List.hotelList;
import static com.example.hotel.Hotel_List.picture1;
import static com.example.hotel.Login.postion;
import static com.example.hotel.Register.jArrayLogin;
import static com.example.hotel.Register.loginData;
import static com.example.hotel.Register.userList;

public class TabFragment1 extends Fragment {
    View view;
    private JSONArray jsonArray;
    public static int choice;
    public static String hotel;
    TextView nameView,priceView,priceView1,locationView,facilitiesView,contextView;
    ImageView imageView;
    ImageView likeButton;
    String userId,userName,userPw,userEmail,userPh,userLike,userId1,userName1,userPw1,userEmail1,userPh1,userLike1;
    File userPf,userPf1;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.tap_fragment1,container,false);
        userList.clear();

        SharedPreferences sf = getActivity().getSharedPreferences("shared", 0);
        hotelList=sf.getString("hotelList","");
        SharedPreferences log =  getActivity().getSharedPreferences("shared", 0);
        loginData=log.getString("loginData","");
        try {
            jArrayLogin = new JSONArray(loginData);
            for (int i = 0; i < jArrayLogin.length(); i++) {
                JSONObject jObject = jArrayLogin.getJSONObject(i);

                 userId = jObject.getString("userId");
                 userName = jObject.getString("userName");
                 userPw = jObject.getString("userPw");
                 userEmail = jObject.getString("userEmail");
                 userPh = jObject.getString("userPh");
                 userPf = new File(jObject.getString("userPf"));
                 userLike = jObject.getString("userLike");

                User user = new User(userId, userName, userPw, userEmail, userPh, userPf, userLike);
                userList.add(user); //첫 줄에 삽입
                Log.d("log", jArrayLogin.toString());
                Log.d("log", String.valueOf(postion));
                Log.d("log1", String.valueOf(userList));
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            jArrayLogin = new JSONArray(loginData);
            {
                JSONObject jObject = jArrayLogin.getJSONObject(postion);
                userId1 = jObject.getString("userId");
                userName1 = jObject.getString("userName");
                userPw1 = jObject.getString("userPw");
                userEmail1 = jObject.getString("userEmail");
                userPh1 = jObject.getString("userPh");
                userPf1 = new File(jObject.getString("userPf"));
                userLike1 = jObject.getString("userLike");
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        likeButton=(ImageView)view.findViewById(R.id.likeButton);
        likeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                likeButton.setImageResource(R.drawable.like);

                User user = new User(userId1,userName1,userPw1,userEmail1,userPh1,userPf1,"dd");
                userList.set(postion, user);
                Log.d("log1", String.valueOf(userList));
                try {
                    jArrayLogin = new JSONArray();//배열이 필요할때
                    for (int i = 0; i < userList.size(); i++) {
                        JSONObject sObject = new JSONObject();//배열 내에 들어갈 json
                        sObject.put("userId", userList.get(i).getUserID());
                        sObject.put("userName", userList.get(i).getUserName());
                        sObject.put("userPw", userList.get(i).getUserPw());
                        sObject.put("userEmail", userList.get(i).getUserEmail());
                        sObject.put("userPh", userList.get(i).getUserPhone());
                        sObject.put("userPf", userList.get(i).getProfile());
                        sObject.put("userLike", userList.get(i).getLike());
                        jArrayLogin.put(sObject);

                        Log.d("JSON Test",jArrayLogin.toString());
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                for (int i = 0; i < userList.size(); i++) {
                    SharedPreferences sf = getActivity().getSharedPreferences("shared", 0);
                    SharedPreferences.Editor editor = sf.edit();//저장하려면 editor가 필요
                    loginData = jArrayLogin.toString();
                    editor.putString("loginData", jArrayLogin.toString());
                    editor.commit(); //완료한다.
                    Log.d("data Test",loginData);
                }
            }
        });
        try {
            jsonArray = new JSONArray(hotelList);
                JSONObject jObject = jsonArray.getJSONObject(choice);
                picture1 = new File(jObject.getString("picture"));
                String hotel = jObject.getString("hotel");
                String price = jObject.getString("price");
                String price1 = jObject.getString("price1");
                String location = jObject.getString("location");
                String facilities = jObject.getString("facilities");
                String context = jObject.getString("context");
                imageView=(ImageView)view.findViewById(R.id.hotelImage);
                nameView =(TextView)view.findViewById(R.id.nameText);
                priceView =(TextView)view.findViewById(R.id.priceText);
                priceView1 =(TextView)view.findViewById(R.id.priceText1);
                locationView =(TextView)view.findViewById(R.id.locationText);
                facilitiesView =(TextView)view.findViewById(R.id.facilitiesText);
                contextView =(TextView)view.findViewById(R.id.hotelContext);

            imageView.setImageURI(Uri.fromFile(picture1));
            nameView.setText(hotel);
            priceView.setText(price);
            priceView1.setText(price1);
            locationView.setText(location);
            facilitiesView.setText(facilities);
            contextView.setText(context);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return view;


    }
}
