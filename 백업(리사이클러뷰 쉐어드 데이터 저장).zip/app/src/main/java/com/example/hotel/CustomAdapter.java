package com.example.hotel;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.util.TypedValue;
import android.view.ContextMenu;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import static com.example.hotel.TabFragment2.jArray;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.CustomViewHolder> {

    private ArrayList<Dictionary> mList;
    private Context mContext;
    ImageView imageViewPicture;
    private final int GET_GALLERY_IMAGE = 200;

    public class CustomViewHolder extends RecyclerView.ViewHolder implements View.OnCreateContextMenuListener { // 1. 리스너 추가
        protected TextView title;
        protected ImageView picture;
        protected TextView content;


        public CustomViewHolder(View view) {
            super(view);
            this.title = (TextView) view.findViewById(R.id.title_listitem);
            this.picture = (ImageView) view.findViewById(R.id.imageView);
            this.content = (TextView) view.findViewById(R.id.content_listitem);

            view.setOnCreateContextMenuListener(this); //2. 리스너 등록
        }


        @Override
        public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {  // 3. 메뉴 추가

            MenuItem Edit = menu.add(Menu.NONE, 1001, 1, "편집");
            MenuItem Delete = menu.add(Menu.NONE, 1002, 2, "삭제");
            Edit.setOnMenuItemClickListener(onEditMenu);
            Delete.setOnMenuItemClickListener(onEditMenu);

        }

        // 4. 캔텍스트 메뉴 클릭시 동작을 설정

        private final MenuItem.OnMenuItemClickListener onEditMenu = new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {


                switch (item.getItemId()) {
                    case 1001:
                        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                        View view = LayoutInflater.from(mContext).inflate(R.layout.edit_box, null, false);
                        builder.setView(view);
                        final Button ButtonSubmit = (Button) view.findViewById(R.id.button_dialog_submit);
                        final EditText editTextTitle = (EditText) view.findViewById(R.id.edittext_dialog_title);
                        TabFragment2.imageViewPicture = (ImageView) view.findViewById(R.id.imageView2);
                        final EditText editTextContent = (EditText) view.findViewById(R.id.edittext_dialog_content);

                        TabFragment2.imageViewPicture.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {
                                Intent intent = new Intent(Intent.ACTION_PICK);
                                intent.setDataAndType(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
                                ((Activity) mContext).startActivityForResult(intent, GET_GALLERY_IMAGE);

                            }
                        });

                        editTextTitle.setText(mList.get(getAdapterPosition()).getTitle());
                        TabFragment2.imageViewPicture.setImageURI(mList.get(getAdapterPosition()).getPicture());
                        editTextContent.setText(mList.get(getAdapterPosition()).getContent());

                        final AlertDialog dialog = builder.create();
                        ButtonSubmit.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {
                                String strID = editTextTitle.getText().toString();
                                String strContent = editTextContent.getText().toString();

                                Dictionary dict = new Dictionary(strID, TabFragment2.selectedImageUri, strContent);

                                mList.set(getAdapterPosition(), dict);
                                notifyItemChanged(getAdapterPosition());
                                try {
                                    jArray = new JSONArray();//배열이 필요할때
                                    for (int i = 0; i < mList.size(); i++) {
                                        JSONObject sObject = new JSONObject();//배열 내에 들어갈 json
                                        sObject.put("title", mList.get(i).getTitle());
                                        sObject.put("picture", mList.get(i).getPicture());
                                        sObject.put("content", mList.get(i).getContent());
                                        jArray.put(sObject);

                                        Log.d("JSON Test", jArray.toString());

                                    }

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                dialog.dismiss();
                            }
                        });

                        dialog.show();

                        break;

                    case 1002:

                        mList.remove(getAdapterPosition());
                        notifyItemRemoved(getAdapterPosition());
                        notifyItemRangeChanged(getAdapterPosition(), mList.size());
                        try {
                            jArray = new JSONArray();//배열이 필요할때
                            for (int i = 0; i < mList.size(); i++) {
                                JSONObject sObject = new JSONObject();//배열 내에 들어갈 json
                                sObject.put("title", mList.get(i).getTitle());
                                sObject.put("picture", mList.get(i).getPicture());
                                sObject.put("content", mList.get(i).getContent());
                                jArray.put(sObject);

                                Log.d("JSON Test", jArray.toString());

                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        break;

                }
                return true;
            }
        };
    }


//    public CustomAdapter(ArrayList<Dictionary> list) {
//        this.mList = list;
//    }

    public CustomAdapter(Context context, ArrayList<Dictionary> list) {
        mList = list;
        mContext = context;

    }


    public CustomAdapter(ArrayList<Dictionary> list) {
        this.mList = list;
    }


    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {

        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.list_item1, viewGroup, false);

        CustomViewHolder viewHolder = new CustomViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder viewholder, int position) {

        viewholder.title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);

        viewholder.content.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);

        viewholder.title.setGravity(Gravity.START);

        viewholder.content.setGravity(Gravity.START);


        viewholder.title.setText(mList.get(position).getTitle());
        viewholder.picture.setImageURI(mList.get(position).getPicture());
        viewholder.content.setText(mList.get(position).getContent());
    }

    @Override
    public int getItemCount() {
        return (null != mList ? mList.size() : 0);
    }

}
