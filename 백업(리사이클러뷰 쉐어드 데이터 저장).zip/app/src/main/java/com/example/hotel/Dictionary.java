package com.example.hotel;

import android.net.Uri;

public class Dictionary {
    private String title;
    private Uri Picture;
    private String Content;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Uri getPicture() {
        return Picture;
    }

    public void setPicture(Uri picture) {
        Picture = picture;
    }

    public String getContent() {
        return Content;
    }

    public void setContent(String content) {
        content = content;
    }

    public Dictionary(String title, Uri picture, String content) {
        this.title = title;
        Picture = picture;
        Content = content;
    }
}
