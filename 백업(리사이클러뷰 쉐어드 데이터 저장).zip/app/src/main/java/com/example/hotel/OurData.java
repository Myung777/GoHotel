package com.example.hotel;

public class OurData {
    public static  String[] title = new String[]{
            "신라호텔",
            "콘래드 호텔",
            "해비치 호텔",
            "힐튼호텔 ",
            "반얀트리 클럽앤스파",
            "파라다이스 호텔",
            "인터컨티넨탈호텔",
            "쉐라톤호텔",

    };
    public static  String[] content = new String[]{
            "5성급 '수영장이 좋음'",
            "5성급 '도시전망'",
            "4성급 '전망이 좋음'",
            "4성급 '수영장이 좋음'",
            "5성급 '강이보이는 전망'",
            "4성급 '맛있는 아침식사'",
            "4성급 '직원이 친절함'",
            "5성급 '위치가 좋음'",

    };
    public  static  int[] picturePath = new int[]{
            R.drawable.hotel3,
            R.drawable.hotel1,
            R.drawable.hotel2,
            R.drawable.hotel2,
            R.drawable.hotel2,
            R.drawable.hotel2,
            R.drawable.hotel2,
            R.drawable.hotel2
    };
}
