package com.example.hotel;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class TabFragment1 extends Fragment {
    View view;
    String HotelList=
            "[{\"hotelImage\":\"1\",\"nameText\":\"신라호텔\",\"priceText\":\"100000\",\"priceText1\":\"2인실:100000\n4인실:150000\",\"locationText\":\"효령로 427, 서초구, 서울, 대한민국\",\"facilitiesText\":\"무료와이파이,에어컨,안전금고,tv\",\"hotelContext\":\"2017년 오픈한 땡땡떙나나나나나 아아아아아아ㅝㅝㄹㄴㅇㄴㄹㅇ\"}," +
                    "{\"hotelImage\":\"2\",\"nameText\":\"#82b92c\",\"priceText\":\"123\",\"priceText1\":\"Hello World\",\"locationText\":\"Hello World\",\"facilitiesText\":\"Hello World\",\"hotelContext\":\"Hello World\"},"+
                    "{\"hotelImage\":\"3\",\"nameText\":\"#82b92c\",\"priceText\":\"123\",\"priceText1\":\"Hello World\",\"locationText\":\"Hello World\",\"facilitiesText\":\"Hello World\",\"hotelContext\":\"Hello World\"}," +
                    "{\"hotelImage\":\"1\",\"nameText\":\"#82b92c\",\"priceText\":\"123\",\"priceText1\":\"Hello World\",\"locationText\":\"Hello World\",\"facilitiesText\":\"Hello World\",\"hotelContext\":\"Hello World\"}," +
                    "{\"hotelImage\":\"1\",\"nameText\":\"#82b92c\",\"priceText\":\"123\",\"priceText1\":\"Hello World\",\"locationText\":\"Hello World\",\"facilitiesText\":\"Hello World\",\"hotelContext\":\"Hello World\"}," +
                    "{\"hotelImage\":\"3\",\"nameText\":\"#82b92c\",\"priceText\":\"123\",\"priceText1\":\"Hello World\",\"locationText\":\"Hello World\",\"facilitiesText\":\"Hello World\",\"hotelContext\":\"Hello World\"}]";
    private JSONArray jsonArray;
    public static int choice;
    TextView nameView,priceView,priceView1,locationView,facilitiesView,contextView;
    ImageView imageView;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.tap_fragment1,container,false);
        try {
            jsonArray = new JSONArray(HotelList);
                JSONObject jsonObject = jsonArray.getJSONObject(choice);
                String hotelImage =jsonObject.getString("hotelImage");
                String nameText = jsonObject.getString("nameText");
                String priceText = jsonObject.getString("priceText");
                String priceText1 = jsonObject.getString("priceText1");
                String locationText = jsonObject.getString("locationText");
                String facilitiesText = jsonObject.getString("facilitiesText");
                String hotelContext = jsonObject.getString("hotelContext");
            Log.d("test", hotelImage);
            imageView=(ImageView)view.findViewById(R.id.hotelImage);
            nameView =(TextView)view.findViewById(R.id.nameText);
            priceView =(TextView)view.findViewById(R.id.priceText);
            priceView1 =(TextView)view.findViewById(R.id.priceText1);
            locationView =(TextView)view.findViewById(R.id.locationText);
            facilitiesView =(TextView)view.findViewById(R.id.facilitiesText);
            contextView =(TextView)view.findViewById(R.id.hotelContext);

            imageView.setImageResource(OurData.picturePath[Integer.parseInt(hotelImage)]);
            nameView.setText(nameText);
            priceView.setText(priceText);
            priceView1.setText(priceText1);
            locationView.setText(locationText);
            facilitiesView.setText(facilitiesText);
            contextView.setText(hotelContext);


        } catch (JSONException e) {
            e.printStackTrace();
        }


        return view;


    }
}
