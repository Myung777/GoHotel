package com.example.hotel;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class MyPage extends Fragment {

    private View view;
    Button btnNum,btnLogout;
    TextView txt;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.activity_mypage,container,false);

        btnLogout = (Button) view.findViewById(R.id.btnLogout);
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()){
                    case R.id.btnLogout:
                        //FirebaseAuth.getInstance().signOut();
                        Intent intent = new Intent(getActivity(),Login.class);
                        startActivity(intent);
                        getActivity().finish();
                        break;
                }
            }
        });

        txt = (TextView)view.findViewById(R.id.textNum);
        btnNum = (Button) view.findViewById(R.id.btnNum);
        btnNum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              if(Hotel_List.coupon==7)
              {
                  txt.setText("많이 이용해 주셔서 감사합니다.\n쿠폰번호 : 1111-1111-4538");
              }
            }
        });

        return view;
    }
}
