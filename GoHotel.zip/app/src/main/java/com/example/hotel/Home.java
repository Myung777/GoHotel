package com.example.hotel;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ScrollView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class Home extends Fragment {
    private View view;
    Button btnCall;
    ScrollView scrollView;
    private static Handler mHandler;
    ImageView adImage;
    int i=0;


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.activity_home, container, false);

        scrollView = (ScrollView) view.findViewById(R.id.scrollView);
        btnCall = (Button) view.findViewById(R.id.btnCall);
        btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:01064125813"));
                startActivity(intent);

            }
        });
        ImageView btn = (ImageView) view.findViewById(R.id.logo);
        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (v.getId() == R.id.logo) {
                    scrollView.fullScroll(ScrollView.FOCUS_UP);
                }
            }
        });

        mHandler = new Handler() {
            @Override
            public void handleMessage(Message msg) {

                adImage = view.findViewById(R.id.adImage);
                if(i==0) {
                    i=1;
                    adImage.setImageResource(R.drawable.hotel2);


                }
                else if(i==1){
                    i=2;
                    adImage.setImageResource(R.drawable.hotel3);

                }
                else if(i==2){
                    i=0;
                    adImage.setImageResource(R.drawable.hotel1);

                }

            }
        };

        class NewRunnable implements Runnable {
            @Override
            public void run() {
                while (true) {

                    try {
                        Thread.sleep(3000);


                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    mHandler.sendEmptyMessage(0);
                }
            }
        }

        NewRunnable nr = new NewRunnable();
        Thread t = new Thread(nr);
        t.start();

        return view;

    }



}
