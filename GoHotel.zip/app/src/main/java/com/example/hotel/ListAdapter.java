package com.example.hotel;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import static com.example.hotel.TabFragment1.choice;

public class ListAdapter extends RecyclerView.Adapter {

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item,parent,false);
        final  ListViewHolder vHolder= new ListViewHolder(view);


        return vHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((ListViewHolder)holder).bindView(position);
    }

    @Override
    public int getItemCount() {
        return OurData.title.length;
    }
    private  class ListViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        private TextView mItemText;
        private TextView mItemText1;
        private ImageView mItemImage;
        public ListViewHolder(View itemView){
            super(itemView);
            mItemText=(TextView)itemView.findViewById(R.id.itemText);
            mItemText1=(TextView)itemView.findViewById(R.id.itemText1);
            mItemImage=(ImageView)itemView.findViewById(R.id.itemImage);
            itemView.setOnClickListener(this);

        }
        public void bindView(int position){
            mItemText1.setText(OurData.content[position]);
            mItemText.setText(OurData.title[position]);
            mItemImage.setImageResource(OurData.picturePath[position]);
        }

        @Override
        public void onClick(View view) {
            if (getAdapterPosition() == 0) {
                Intent intent = new Intent(view.getContext(),Hotel_main.class);
                view.getContext().startActivity(intent);
                choice=0;

            }
            else if (getAdapterPosition() == 1) {
                Intent intent = new Intent(view.getContext(),Hotel_main.class);
                view.getContext().startActivity(intent);
                choice=1;
            }
        }
    }
}
