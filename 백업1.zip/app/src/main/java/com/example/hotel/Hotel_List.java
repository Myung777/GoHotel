package com.example.hotel;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Hotel_List extends Fragment {
    private ArrayList<Favorite> favoritesList = new ArrayList<>();
    private RecyclerView recyclerView;
    private FavoriteAdapter mAdapter;



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.activity_hotel__list, container, false);

        recyclerView = (RecyclerView) v.findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);
        mAdapter = new FavoriteAdapter(favoritesList);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);

        return v;
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prepareData();
    }

    private void prepareData() {
        favoritesList.add(new Favorite("서울시청",37.54892296550104,126.99089033876304));
        favoritesList.add(new Favorite("경복궁",37.54892296550104,126.99089033876304));
        favoritesList.add(new Favorite("서울역",37.54892296550104,126.99089033876304));
        favoritesList.add(new Favorite("남산",37.54892296550104,126.99089033876304));
        favoritesList.add(new Favorite("을지로입구역",37.54892296550104,126.99089033876304));
    }


}
