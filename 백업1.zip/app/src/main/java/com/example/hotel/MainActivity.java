package com.example.hotel;

import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private BottomNavigationView bottomNavigationView;
    private FragmentManager fm;
    private FragmentTransaction ft;
    private Home home;
    private Hotel_List hotel_list;
    private PopularHotel popularHotel;
    private Mypage mypage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("on","onCreate");
        Toast.makeText(this, "onCreate", Toast.LENGTH_SHORT).show();


        bottomNavigationView = findViewById(R.id.bottomNavi);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()){
                    case R.id.action_home:
                        setFrag(0);
                        break;
                    case R.id.action_hotel:
                        setFrag(1);
                        break;
                    case R.id.action_rank:
                        setFrag(2);
                        break;
                    case R.id.action_user:
                        setFrag(3);
                        break;
                }
                return true;
            }
        });
        home=new Home();
        hotel_list = new Hotel_List();
        popularHotel= new PopularHotel();
        mypage = new Mypage();
        setFrag(0);



    }
    private void setFrag(int n){
        fm=getSupportFragmentManager();
        ft=fm.beginTransaction();
        switch (n){
            case 0:
                ft.replace(R.id.main_frame,home);
                ft.commit();
                break;
            case 1:
                ft.replace(R.id.main_frame,hotel_list);
                ft.commit();
                break;
            case 2:
                ft.replace(R.id.main_frame,popularHotel);
                ft.commit();
                break;
            case 3:
                ft.replace(R.id.main_frame,mypage);
                ft.commit();
                break;
        }
    }
    @Override
    protected void onStop() {
        super.onStop();
        Log.i("on", "onStop: ");
        Toast.makeText(this, "onStop", Toast.LENGTH_SHORT).show();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("on", "onDestroy: ");
        Toast.makeText(this, "onDestroy", Toast.LENGTH_SHORT).show();

    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i("on", "onPause: ");
        Toast.makeText(this, "onPause", Toast.LENGTH_SHORT).show();

    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("on", "onResume: ");
        Toast.makeText(this, "onResume", Toast.LENGTH_SHORT).show();

    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i("on", "onStart: ");
        Toast.makeText(this, "onStart", Toast.LENGTH_SHORT).show();

    }
    @Override

    protected void onRestart() {
        super.onRestart();
        Toast.makeText(this, "onRestart", Toast.LENGTH_SHORT).show();
        Log.i("on", "onRestart: ");

    }



}
