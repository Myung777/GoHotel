package com.example.hotel;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ScrollView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class PopularHotel extends Fragment {

    private View view;
    ScrollView scrollView;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.activity_popular_hotel,container,false);
        scrollView = (ScrollView) view.findViewById(R.id.scrollView);
        ImageView btn = (ImageView) view.findViewById(R.id.logo);
        btn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                if(v.getId() ==R.id.logo){
                    scrollView.fullScroll(ScrollView.FOCUS_UP);
                }
            }
        });
        return view;
    }
}
