package com.example.hotel;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Register extends AppCompatActivity {
    private static final String TAG="signUPActivity";
    private FirebaseAuth mAuth;
    public static  ArrayList<User> userList = new ArrayList<>();
    public static JSONArray jArrayLogin;
    public static String loginData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        findViewById(R.id.btnJoin).setOnClickListener(onClickListener);
        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();


    }

    View.OnClickListener onClickListener =new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.btnJoin:
                    signUp();
                break;
            }
        }
    };

    private void signUp(){

        String email=((EditText)findViewById(R.id.emailEditText)).getText().toString();
        String password=((EditText)findViewById(R.id.pwEditText)).getText().toString();

        User user = new User(email, password );
        userList.add(0, user); //첫 줄에 삽입
        if(email.length()>0&&password.length()>0) {
            try {
                jArrayLogin = new JSONArray();//배열이 필요할때
                for (int i = 0; i < userList.size(); i++) {
                    JSONObject sObject = new JSONObject();//배열 내에 들어갈 json
                    sObject.put("userId", userList.get(i).getUserID());
                    sObject.put("userPw", userList.get(i).getUserPw());
                    jArrayLogin.put(sObject);

                    Log.d("JSON Test",jArrayLogin.toString());

                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

            for (int i = 0; i < userList.size(); i++) {
                SharedPreferences sf = getSharedPreferences("shared", 0);
                SharedPreferences.Editor editor = sf.edit();//저장하려면 editor가 필요
                loginData = jArrayLogin.toString();
                editor.putString("loginData", jArrayLogin.toString());
                editor.commit(); //완료한다.
                Log.d("data Test",loginData);

            }
            Intent intent = new Intent(Register.this, Login.class);
            startActivity(intent);
            finish();
        }
        else{
            Toast.makeText(Register.this, "이메일 또는 비밀번호는 입력해주세요.", Toast.LENGTH_SHORT).show();
        }
    }

}
