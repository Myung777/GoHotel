package com.example.hotel;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static com.example.hotel.Register.jArrayLogin;
import static com.example.hotel.Register.loginData;

public class Login extends AppCompatActivity {

    private FirebaseAuth mAuth;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        findViewById(R.id.btnJoin).setOnClickListener(onClickListener);
        findViewById(R.id.btnLogin).setOnClickListener(onClickListener);
        findViewById(R.id.btnPwReset).setOnClickListener(onClickListener);
        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();


    }

    View.OnClickListener onClickListener =new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.btnJoin:
                    Intent intent = new Intent(Login.this,Register.class);
                    startActivity(intent);
                    finish();
                    break;
                case R.id.btnLogin:
                    login();
                    break;
                case R.id.btnPwReset:
                    Intent intent1 = new Intent(Login.this,PwReset.class);
                    startActivity(intent1);
                    break;
            }
        }
    };

    /*@Override
    public void  onBackPressed(){
        super.onBackPressed();
        moveTaskToBack(true);
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(1);
    }*/

    private void login(){
        SharedPreferences sf = getSharedPreferences("shared", 0);
        loginData=sf.getString("loginData","");
        Log.d("loginData",loginData);

        String email=((EditText)findViewById(R.id.emailEditText1)).getText().toString();
        String password=((EditText)findViewById(R.id.pwEditText)).getText().toString();

        if(email.length()>0&&password.length()>0) {
            if(loginData!=null) {
                try {
                    jArrayLogin = new JSONArray(loginData);
                    for (int i = 0; i < jArrayLogin.length(); i++) {
                        JSONObject jObject = jArrayLogin.getJSONObject(i);
                        String id = jObject.getString("userId");
                        String pw = jObject.getString("userPw");

                        Log.d("data Test", id);
                        Log.d("data Test", pw);
                        if (id.equals(email) && pw.equals(password)) {
                            Intent intent = new Intent(Login.this, MainActivity.class);
                            startActivity(intent);
                            finish();
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
        else{
            Toast.makeText(Login.this, "이메일 또는 비밀번호는 입력해주세요.", Toast.LENGTH_SHORT).show();
        }
    }

}

