package com.example.hotel;

public class Item {

    String name;
    int photo;
    String summary;

    public Item(String name, int photo, String summary) {
        this.name = name;
        this.photo = photo;
        this.summary = summary;
    }

    public String getName() {
        return name;
    }

    public int getPhoto() {
        return photo;
    }

    public String getSummary() {
        return summary;
    }
}
