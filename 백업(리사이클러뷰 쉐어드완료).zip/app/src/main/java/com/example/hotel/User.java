package com.example.hotel;

public class User {
    private String userID;
    private String userPw;

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getUserPw() {
        return userPw;
    }

    public void setUserPw(String userPw) {
        this.userPw = userPw;
    }

    public User(String userID, String userPw) {
        this.userID = userID;
        this.userPw = userPw;
    }
}

